/*
 * test_snfs.c - Cliente de teste para o servidor SNFS
 * Testa: ping, create, write, read, mkdir, readdir
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SERVER_SOCK "/tmp/server.socket"
#define CLIENT_SOCK "/tmp/test_client.socket"

#define MAX_FILE_NAME_SIZE 14
#define MAX_READ_DATA 1024
#define MAX_WRITE_DATA 1024
#define MAX_READDIR_ENTRIES 64

typedef int snfs_fhandle_t;
typedef enum {SNFS_DIR=1, SNFS_FILE=2} snfs_dir_entry_type_t;
typedef struct { char name[MAX_FILE_NAME_SIZE]; int len; snfs_dir_entry_type_t type; } snfs_dir_entry_t;
typedef enum {REQ_NULL=0,REQ_PING=1,REQ_LOOKUP=2,REQ_READ=3,REQ_WRITE=4,REQ_CREATE=5,REQ_MKDIR=6,REQ_READDIR=7,REQ_COPY=8} snfs_msg_type_t;
typedef enum {RES_OK=0,RES_ERROR=-1,RES_UNKNOWN=-2} snfs_msg_res_status_t;

typedef struct { char msg[256]; } snfs_msg_req_ping_t;
typedef struct { char msg[256]; } snfs_msg_res_ping_t;
typedef struct { char pname[MAX_FILE_NAME_SIZE]; } snfs_msg_req_lookup_t;
typedef struct { snfs_fhandle_t file; unsigned fsize; } snfs_msg_res_lookup_t;
typedef struct { snfs_fhandle_t fhandle; unsigned offset; unsigned count; } snfs_msg_req_read_t;
typedef struct { char data[MAX_READ_DATA]; unsigned nread; } snfs_msg_res_read_t;
typedef struct { snfs_fhandle_t fhandle; unsigned offset; unsigned count; char data[MAX_WRITE_DATA]; } snfs_msg_req_write_t;
typedef struct { unsigned fsize; } snfs_msg_res_write_t;
typedef struct { snfs_fhandle_t dir; char name[MAX_FILE_NAME_SIZE]; } snfs_msg_req_create_t;
typedef struct { snfs_fhandle_t file; } snfs_msg_res_create_t;
typedef struct { snfs_fhandle_t dir; unsigned cmax; } snfs_msg_req_readdir_t;
typedef struct { unsigned count; snfs_dir_entry_t list[MAX_READDIR_ENTRIES]; } snfs_msg_res_readdir_t;
typedef struct { snfs_fhandle_t dir; char file[MAX_FILE_NAME_SIZE]; } snfs_msg_req_mkdir_t;
typedef struct { snfs_fhandle_t newdirid; } snfs_msg_res_mkdir_t;

typedef struct {
    snfs_msg_type_t type;
    int sn;
    union {
        snfs_msg_req_ping_t ping;
        snfs_msg_req_lookup_t lookup;
        snfs_msg_req_read_t read;
        snfs_msg_req_write_t write;
        snfs_msg_req_create_t create;
        snfs_msg_req_mkdir_t mkdir;
        snfs_msg_req_readdir_t readdir;
    } body;
} snfs_msg_req_t;

typedef struct {
    snfs_msg_type_t type;
    int sn;
    snfs_msg_res_status_t status;
    union {
        snfs_msg_res_ping_t ping;
        snfs_msg_res_lookup_t lookup;
        snfs_msg_res_read_t read;
        snfs_msg_res_write_t write;
        snfs_msg_res_create_t create;
        snfs_msg_res_mkdir_t mkdir;
        snfs_msg_res_readdir_t readdir;
    } body;
} snfs_msg_res_t;

static int sockfd = -1;
static struct sockaddr_un servaddr;
static int sn_counter = 1;

void init_socket() {
    unlink(CLIENT_SOCK);
    sockfd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    struct sockaddr_un cliaddr;
    memset(&cliaddr, 0, sizeof(cliaddr));
    cliaddr.sun_family = AF_UNIX;
    strcpy(cliaddr.sun_path, CLIENT_SOCK);
    if (bind(sockfd, (struct sockaddr*)&cliaddr, sizeof(cliaddr)) < 0) {
        perror("bind"); exit(1);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sun_family = AF_UNIX;
    strcpy(servaddr.sun_path, SERVER_SOCK);
}

int send_recv(snfs_msg_req_t* req, int reqsz, snfs_msg_res_t* res) {
    req->sn = sn_counter++;
    if (sendto(sockfd, req, reqsz, 0, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) {
        perror("sendto"); return -1;
    }
    socklen_t len = sizeof(servaddr);
    int n = recvfrom(sockfd, res, sizeof(*res), 0, NULL, &len);
    if (n < 0) { perror("recvfrom"); return -1; }
    return 0;
}

void test_ping() {
    printf("\n=== TESTE 1: PING ===\n");
    snfs_msg_req_t req; snfs_msg_res_t res;
    memset(&req, 0, sizeof(req));
    req.type = REQ_PING;
    strcpy(req.body.ping.msg, "ola servidor");
    int sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.ping);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK)
        printf("[OK] Ping respondeu: '%s'\n", res.body.ping.msg);
    else
        printf("[ERRO] Ping falhou\n");
}

void test_create_and_write(snfs_fhandle_t* out_fhandle) {
    printf("\n=== TESTE 2: CREATE ===\n");
    snfs_msg_req_t req; snfs_msg_res_t res;
    memset(&req, 0, sizeof(req));
    req.type = REQ_CREATE;
    req.body.create.dir = 1;
    strcpy(req.body.create.name, "teste.txt");
    int sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.create);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK) {
        *out_fhandle = res.body.create.file;
        printf("[OK] Ficheiro criado com fhandle=%d\n", *out_fhandle);
    } else {
        printf("[ERRO] Create falhou\n");
        *out_fhandle = -1;
        return;
    }

    printf("\n=== TESTE 3: WRITE ===\n");
    memset(&req, 0, sizeof(req));
    req.type = REQ_WRITE;
    req.body.write.fhandle = *out_fhandle;
    req.body.write.offset = 0;
    char* msg = "Ola SNFS! Erros Coders 2025";
    req.body.write.count = strlen(msg);
    memcpy(req.body.write.data, msg, strlen(msg));
    sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.write);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK)
        printf("[OK] Escrita feita, tamanho=%u bytes\n", res.body.write.fsize);
    else
        printf("[ERRO] Write falhou\n");
}

void test_read(snfs_fhandle_t fhandle) {
    printf("\n=== TESTE 4: READ ===\n");
    if (fhandle < 0) { printf("[SKIP] fhandle invalido\n"); return; }
    snfs_msg_req_t req; snfs_msg_res_t res;
    memset(&req, 0, sizeof(req));
    req.type = REQ_READ;
    req.body.read.fhandle = fhandle;
    req.body.read.offset = 0;
    req.body.read.count = 512;
    int sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.read);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK) {
        res.body.read.data[res.body.read.nread] = '\0';
        printf("[OK] Lidos %u bytes: '%s'\n", res.body.read.nread, res.body.read.data);
    } else {
        printf("[ERRO] Read falhou\n");
    }
}

void test_mkdir() {
    printf("\n=== TESTE 5: MKDIR ===\n");
    snfs_msg_req_t req; snfs_msg_res_t res;
    memset(&req, 0, sizeof(req));
    req.type = REQ_MKDIR;
    req.body.mkdir.dir = 1;
    strcpy(req.body.mkdir.file, "docs");
    int sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.mkdir);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK)
        printf("[OK] Directorio 'docs' criado com id=%d\n", res.body.mkdir.newdirid);
    else
        printf("[ERRO] Mkdir falhou\n");
}

void test_readdir() {
    printf("\n=== TESTE 6: READDIR (root) ===\n");
    snfs_msg_req_t req; snfs_msg_res_t res;
    memset(&req, 0, sizeof(req));
    req.type = REQ_READDIR;
    req.body.readdir.dir = 1;
    req.body.readdir.cmax = MAX_READDIR_ENTRIES;
    int sz = sizeof(req.type) + sizeof(req.sn) + sizeof(req.body.readdir);
    if (send_recv(&req, sz, &res) == 0 && res.status == RES_OK) {
        printf("[OK] %u entrada(s) no directorio raiz:\n", res.body.readdir.count);
        for (unsigned i = 0; i < res.body.readdir.count; i++) {
            snfs_dir_entry_t* e = &res.body.readdir.list[i];
            printf("     [%s] %s\n", e->type == SNFS_DIR ? "DIR " : "FILE", e->name);
        }
    } else {
        printf("[ERRO] Readdir falhou\n");
    }
}

int main() {
    printf("=== CLIENTE DE TESTE SNFS ===\n");
    printf("Servidor: %s\n", SERVER_SOCK);
    init_socket();

    snfs_fhandle_t fhandle;
    test_ping();
    test_create_and_write(&fhandle);
    test_read(fhandle);
    test_mkdir();
    test_readdir();

    printf("\n=== TESTES CONCLUIDOS ===\n");
    unlink(CLIENT_SOCK);
    close(sockfd);
    return 0;
}
