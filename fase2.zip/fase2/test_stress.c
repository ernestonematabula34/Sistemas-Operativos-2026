/*
 * test_stress.c - Teste de stress com multiplos clientes em paralelo
 * Lanca N processos filho, cada um faz operacoes concorrentes
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include "include/myfs.h"

#define NUM_CLIENTES 5
#define NUM_OPS      10

void cliente(int id) {
    printf("[cliente %d] iniciando\n", id);

    if (my_init_lib() < 0) {
        printf("[cliente %d] ERRO: my_init_lib falhou\n", id);
        exit(1);
    }

    char filename[32];
    char buf_write[64];
    char buf_read[64];

    for (int i = 0; i < NUM_OPS; i++) {
        /* criar ficheiro unico por cliente */
        snprintf(filename, sizeof(filename), "/cli%d_op%d.txt", id, i);
        snprintf(buf_write, sizeof(buf_write), "cliente=%d operacao=%d", id, i);

        int fd = my_open(filename, 1);
        if (fd < 0) {
            printf("[cliente %d] ERRO: my_open(%s) falhou\n", id, filename);
            continue;
        }

        int nw = my_write(fd, buf_write, strlen(buf_write));
        my_close(fd);

        /* ler de volta */
        fd = my_open(filename, 0);
        if (fd < 0) {
            printf("[cliente %d] ERRO: my_open read(%s) falhou\n", id, filename);
            continue;
        }
        memset(buf_read, 0, sizeof(buf_read));
        int nr = my_read(fd, buf_read, sizeof(buf_read)-1);
        my_close(fd);

        if (strcmp(buf_write, buf_read) == 0) {
            printf("[cliente %d] op%d OK: '%s'\n", id, i, buf_read);
        } else {
            printf("[cliente %d] op%d ERRO: escrito='%s' lido='%s'\n",
                   id, i, buf_write, buf_read);
        }
    }
    printf("[cliente %d] concluido\n", id);
    exit(0);
}

int main() {
    printf("=== TESTE DE STRESS: %d clientes x %d operacoes ===\n",
           NUM_CLIENTES, NUM_OPS);

    pid_t pids[NUM_CLIENTES];

    /* lançar todos os clientes em paralelo */
    for (int i = 0; i < NUM_CLIENTES; i++) {
        pids[i] = fork();
        if (pids[i] == 0) {
            cliente(i);  /* processo filho */
        } else if (pids[i] < 0) {
            perror("fork");
        }
    }

    /* aguardar todos os filhos */
    int ok = 0, err = 0;
    for (int i = 0; i < NUM_CLIENTES; i++) {
        int status;
        waitpid(pids[i], &status, 0);
        if (WIFEXITED(status) && WEXITSTATUS(status) == 0)
            ok++;
        else
            err++;
    }

    printf("\n=== RESULTADO: %d clientes OK, %d com erros ===\n", ok, err);
    return (err == 0) ? 0 : 1;
}
