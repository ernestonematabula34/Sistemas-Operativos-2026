/*
 * SNFS API Layer - snfs_api.c
 * Suporte a N servidores réplica
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <strings.h>

#include <snfs_api.h>
#include <snfs_proto.h>

/* ============================================================
 * Configuração multi-servidor
 * ============================================================ */
#ifndef MAX_SERVERS
#define MAX_SERVERS 8
#endif

/* M servidores a contactar para operações de leitura (M <= N) */
#ifndef NUMBER_OF_SERVERS_TO_CONTACT
#define NUMBER_OF_SERVERS_TO_CONTACT 1
#endif

/* ============================================================
 * Estado interno
 * ============================================================ */
static int Cli_sock;
static struct sockaddr_un Cli_addr;

/* array de endereços dos servidores */
static struct sockaddr_un Serv_addrs[MAX_SERVERS];
static int Num_servers = 0;

/* round-robin para leituras */
static int rr_next = 0;

static snfs_req_serial_num_t next_sn;

/* ============================================================
 * remote_call
 * to_all_servers=1: envia para todos N, aguarda todos N, verifica STATUS
 * to_all_servers=0: envia para M em round-robin, retorna a primeira resposta
 * ============================================================ */
static int remote_call(snfs_msg_req_t *req, int reqsz, snfs_msg_res_t *res,
   int ressz, int to_all_servers)
{
   int status;
   req->sn = (next_sn++);

   if (Num_servers == 0) {
      printf("[snfs_api] erro: nenhum servidor configurado.\n");
      return -1;
   }

   if (to_all_servers) {
      /* ---- ESCRITA: enviar para todos N servidores ---- */
      for (int i = 0; i < Num_servers; i++) {
         status = sendto(Cli_sock, (void*)req, reqsz, 0,
            (struct sockaddr*)&Serv_addrs[i], sizeof(Serv_addrs[i]));
         if (status < 0) {
            printf("[snfs_api] sendto server %d error: %s.\n", i, strerror(errno));
            return -1;
         }
      }

      /* aguardar resposta de todos N servidores */
      snfs_msg_res_status_t first_status = RES_UNKNOWN;
      snfs_msg_res_t tmp_res;
      int got_first = 0;

      for (int i = 0; i < Num_servers; i++) {
         status = recvfrom(Cli_sock, &tmp_res, ressz, 0, NULL, NULL);
         if (status < 0) {
            printf("[snfs_api] recvfrom server %d error: %s.\n", i, strerror(errno));
            return -1;
         }
         if (!got_first) {
            *res = tmp_res;
            first_status = tmp_res.status;
            got_first = 1;
         } else {
            /* verificar STATUS idêntico */
            if (tmp_res.status != first_status) {
               printf("[snfs_api] FALHA GRAVE: servidores retornaram STATUS diferentes!\n");
               exit(-1);
            }
         }
      }
      return status;

   } else {
      /* ---- LEITURA: enviar para M servidores em round-robin ---- */
      int m = NUMBER_OF_SERVERS_TO_CONTACT;
      if (m > Num_servers) m = Num_servers;

      for (int i = 0; i < m; i++) {
         int idx = (rr_next + i) % Num_servers;
         status = sendto(Cli_sock, (void*)req, reqsz, 0,
            (struct sockaddr*)&Serv_addrs[idx], sizeof(Serv_addrs[idx]));
         if (status < 0) {
            printf("[snfs_api] sendto server %d error: %s.\n", idx, strerror(errno));
            return -1;
         }
      }
      rr_next = (rr_next + m) % Num_servers;

      /* retornar a primeira resposta que chegar */
      status = recvfrom(Cli_sock, res, ressz, 0, NULL, NULL);
      if (status < 0) {
         printf("[snfs_api] recvfrom error: %s.\n", strerror(errno));
         return -1;
      }
      if (status == 0) {
         printf("[snfs_api] servidor fechado.\n");
         return -1;
      }

      /* descartar respostas restantes (non-blocking) */
      snfs_msg_res_t discard;
      for (int i = 1; i < m; i++) {
         recvfrom(Cli_sock, &discard, sizeof(discard), MSG_DONTWAIT, NULL, NULL);
      }

      return status;
   }
}

/* ============================================================
 * snfs_init — suporta nome base do servidor
 * Se existir server_name_1, server_name_2, ... usa múltiplos
 * Caso contrário usa server_name directamente (compatibilidade)
 * ============================================================ */
int snfs_init(char* cli_name, char* server_name)
{
   if (cli_name == NULL || server_name == NULL) {
      printf("[snfs_api] invalid client/server address names.\n");
      return -1;
   }

   if ((Cli_sock = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
      printf("[snfs_api] socket error: %s.\n", strerror(errno));
      return -1;
   }

   if (unlink(cli_name) < 0 && errno != ENOENT) {
      printf("[snfs_api] unlink error: %s.\n", strerror(errno));
   }

   bzero(&Cli_addr, sizeof(Cli_addr));
   Cli_addr.sun_family = AF_UNIX;
   strcpy(Cli_addr.sun_path, cli_name);

   if (bind(Cli_sock, (struct sockaddr*)&Cli_addr, sizeof(Cli_addr)) < 0) {
      printf("[snfs_api] bind error: %s.\n", strerror(errno));
      return -1;
   }

   /* descobrir quantos servidores existem: server_name_1, server_name_2, ... */
   Num_servers = 0;
   for (int i = 1; i <= MAX_SERVERS; i++) {
      char path[128];
      snprintf(path, sizeof(path), "%s_%d", server_name, i);
      /* verificar se o socket existe */
      struct sockaddr_un tmp;
      bzero(&tmp, sizeof(tmp));
      tmp.sun_family = AF_UNIX;
      strcpy(tmp.sun_path, path);
      /* tentar enviar 0 bytes para ver se existe */
      int test = sendto(Cli_sock, "", 0, 0,
         (struct sockaddr*)&tmp, sizeof(tmp));
      if (test >= 0 || errno != ENOENT) {
         Serv_addrs[Num_servers] = tmp;
         Num_servers++;
         printf("[snfs_api] servidor %d encontrado: %s\n", Num_servers, path);
      } else {
         break;
      }
   }

   /* fallback: usar server_name directamente (modo single-server) */
   if (Num_servers == 0) {
      bzero(&Serv_addrs[0], sizeof(Serv_addrs[0]));
      Serv_addrs[0].sun_family = AF_UNIX;
      strcpy(Serv_addrs[0].sun_path, server_name);
      Num_servers = 1;
      printf("[snfs_api] modo single-server: %s\n", server_name);
   }

   next_sn = 0;
   rr_next = 0;
   return 0;
}

/* ============================================================
 * API SNFS — igual ao original, só muda o remote_call
 * ============================================================ */
snfs_call_status_t snfs_ping(char* inmsg, int insize, char* outmsg, int outsize)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_PING;
   strncpy(req.body.ping.msg, inmsg, insize);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.ping), &res, sizeof(res), 0);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   strncpy(outmsg, res.body.ping.msg, outsize);
   return STAT_OK;
}

snfs_call_status_t snfs_lookup(char* pathname, snfs_fhandle_t* file, unsigned* fsize)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_LOOKUP;
   strcpy(req.body.lookup.pname, pathname);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.lookup), &res, sizeof(res), 0);
   if (status < 0 || res.status != RES_OK) { *file = res.body.lookup.file; return STAT_ERROR; }
   *file = res.body.lookup.file;
   *fsize = res.body.lookup.fsize;
   return STAT_OK;
}

snfs_call_status_t snfs_read(snfs_fhandle_t fhandle, unsigned offset,
   unsigned count, char* buffer, int* nread)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_READ;
   req.body.read.fhandle = fhandle;
   req.body.read.offset = offset;
   req.body.read.count = count;
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.read), &res, sizeof(res), 0);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   memcpy(buffer, res.body.read.data, count);
   *nread = res.body.read.nread;
   return STAT_OK;
}

snfs_call_status_t snfs_write(snfs_fhandle_t fhandle, unsigned offset,
   unsigned count, char* buffer, unsigned int* fsize)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_WRITE;
   req.body.write.fhandle = fhandle;
   req.body.write.offset = offset;
   req.body.write.count = count;
   memcpy(req.body.write.data, buffer, count);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.write), &res, sizeof(res), 1);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   *fsize = res.body.write.fsize;
   return STAT_OK;
}

snfs_call_status_t snfs_create(snfs_fhandle_t dir, char* name, snfs_fhandle_t* file)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_CREATE;
   req.body.create.dir = dir;
   strcpy(req.body.create.name, name);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.create), &res, sizeof(res), 1);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   *file = res.body.create.file;
   return STAT_OK;
}

snfs_call_status_t snfs_mkdir(snfs_fhandle_t dir, char* name, snfs_fhandle_t* file)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_MKDIR;
   req.body.mkdir.dir = dir;
   strcpy(req.body.mkdir.file, name);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.mkdir), &res, sizeof(res), 1);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   *file = res.body.mkdir.newdirid;
   return STAT_OK;
}

snfs_call_status_t snfs_readdir(snfs_fhandle_t dir, unsigned cmax,
   snfs_dir_entry_t* list, unsigned* count)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_READDIR;
   req.body.readdir.dir = dir;
   req.body.readdir.cmax = cmax;
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.readdir), &res, sizeof(res), 0);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   *count = res.body.readdir.count;
   memcpy(list, res.body.readdir.list, sizeof(snfs_dir_entry_t)*(*count));
   return STAT_OK;
}

snfs_call_status_t snfs_copy(char *srcpath, char *tgtpath)
{
   snfs_msg_req_t req; snfs_msg_res_t res;
   memset(&req,0,sizeof(req)); memset(&res,0,sizeof(res));
   req.type = REQ_COPY;
   strcpy(req.body.copy.srcpathname, srcpath);
   strcpy(req.body.copy.tgtpathname, tgtpath);
   int status = remote_call(&req, sizeof(req.sn)+sizeof(req.type)+sizeof(req.body.copy), &res, sizeof(res), 1);
   if (status < 0 || res.status != RES_OK) return STAT_ERROR;
   return STAT_OK;
}

void snfs_finish()
{
   close(Cli_sock);
   unlink(Cli_addr.sun_path);
}
