#include <sthread.h>
#include <stdlib.h>

void io_delay_on(int disk_delay) { (void)disk_delay; }
void io_delay_simulator() { }
void io_delay_read_block() { }
void io_delay_write_block() { }
