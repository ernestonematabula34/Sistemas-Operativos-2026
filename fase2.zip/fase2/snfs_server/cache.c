/*
 * cache.c - Caches de blocos, inodes e directorias com sincronização
 * Politica: LRU com dirty-last, write-back adiado 10s
 * Sincronizacao: monitor por cache (Requisito 3)
 */

#include <string.h>
#include <stdio.h>
#include <time.h>
#include <sthread.h>
#include "cache.h"

/* ============================================================
 * Estado interno
 * ============================================================ */
static block_cache_entry_t block_cache[BLOCK_CACHE_SIZE];
static inode_cache_entry_t inode_cache[INODE_CACHE_SIZE];
static dir_cache_entry_t   dir_cache[DIR_CACHE_SIZE];
static blocks_t* disk = NULL;

/* monitores — um por cache */
static sthread_mon_t mon_block = NULL;
static sthread_mon_t mon_inode = NULL;
static sthread_mon_t mon_dir   = NULL;

/* ============================================================
 * Inicializacao
 * ============================================================ */
void cache_init(blocks_t* bks)
{
    disk = bks;
    memset(block_cache, 0, sizeof(block_cache));
    memset(inode_cache, 0, sizeof(inode_cache));
    memset(dir_cache,   0, sizeof(dir_cache));

    mon_block = sthread_monitor_init();
    mon_inode = sthread_monitor_init();
    mon_dir   = sthread_monitor_init();

    printf("[cache] inicializada: blocos=%d inodes=%d dirs=%d\n",
           BLOCK_CACHE_SIZE, INODE_CACHE_SIZE, DIR_CACHE_SIZE);
}

/* ============================================================
 * LRU: encontrar vitima na cache de blocos
 * ============================================================ */
static int block_cache_find_victim(void)
{
    int victim_clean = -1, victim_dirty = -1;
    time_t oldest_clean = -1, oldest_dirty = -1;

    for (int i = 0; i < BLOCK_CACHE_SIZE; i++) {
        if (!block_cache[i].valid) return i;
        if (!block_cache[i].dirty) {
            if (victim_clean == -1 || block_cache[i].last_access < oldest_clean) {
                oldest_clean = block_cache[i].last_access;
                victim_clean = i;
            }
        } else {
            if (victim_dirty == -1 || block_cache[i].last_access < oldest_dirty) {
                oldest_dirty = block_cache[i].last_access;
                victim_dirty = i;
            }
        }
    }
    return (victim_clean != -1) ? victim_clean : victim_dirty;
}

static void block_cache_flush_entry(int i)
{
    if (block_cache[i].valid && block_cache[i].dirty) {
        block_write(disk, block_cache[i].block_no, block_cache[i].data);
        block_cache[i].dirty = 0;
        printf("[cache] flush bloco %u\n", block_cache[i].block_no);
    }
}

/* ============================================================
 * Cache de blocos: READ — protegido por monitor
 * ============================================================ */
int cache_block_read(unsigned block_no, char* buf)
{
    time_t now = time(NULL);
    sthread_monitor_enter(mon_block);

    /* HIT */
    for (int i = 0; i < BLOCK_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].block_no == block_no) {
            memcpy(buf, block_cache[i].data, BLOCK_SIZE_CACHE);
            block_cache[i].last_access = now;
            printf("[cache] HIT leitura bloco %u\n", block_no);
            sthread_monitor_exit(mon_block);
            return 0;
        }
    }

    /* MISS — sair do monitor para ir ao disco (operação lenta) */
    sthread_monitor_exit(mon_block);
    printf("[cache] MISS leitura bloco %u\n", block_no);
    char tmp[BLOCK_SIZE_CACHE];
    int ret = block_read(disk, block_no, tmp);
    if (ret != 0) return ret;

    /* re-entrar no monitor para inserir na cache */
    sthread_monitor_enter(mon_block);
    /* verificar se outra thread já inseriu entretanto */
    for (int i = 0; i < BLOCK_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].block_no == block_no) {
            memcpy(buf, block_cache[i].data, BLOCK_SIZE_CACHE);
            block_cache[i].last_access = now;
            sthread_monitor_exit(mon_block);
            return 0;
        }
    }
    int victim = block_cache_find_victim();
    block_cache_flush_entry(victim);
    block_cache[victim].valid       = 1;
    block_cache[victim].block_no    = block_no;
    block_cache[victim].dirty       = 0;
    block_cache[victim].last_access = now;
    block_cache[victim].dirty_time  = 0;
    memcpy(block_cache[victim].data, tmp, BLOCK_SIZE_CACHE);
    memcpy(buf, tmp, BLOCK_SIZE_CACHE);
    sthread_monitor_exit(mon_block);
    return 0;
}

/* ============================================================
 * Cache de blocos: WRITE — protegido por monitor
 * ============================================================ */
int cache_block_write(unsigned block_no, char* buf)
{
    time_t now = time(NULL);
    sthread_monitor_enter(mon_block);

    /* HIT */
    for (int i = 0; i < BLOCK_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].block_no == block_no) {
            memcpy(block_cache[i].data, buf, BLOCK_SIZE_CACHE);
            block_cache[i].dirty      = 1;
            block_cache[i].dirty_time = now;
            block_cache[i].last_access = now;
            printf("[cache] HIT escrita bloco %u (dirty)\n", block_no);
            sthread_monitor_exit(mon_block);
            return 0;
        }
    }

    /* MISS */
    printf("[cache] MISS escrita bloco %u\n", block_no);
    int victim = block_cache_find_victim();
    block_cache_flush_entry(victim);
    block_cache[victim].valid       = 1;
    block_cache[victim].block_no    = block_no;
    block_cache[victim].dirty       = 1;
    block_cache[victim].dirty_time  = now;
    block_cache[victim].last_access = now;
    memcpy(block_cache[victim].data, buf, BLOCK_SIZE_CACHE);
    sthread_monitor_exit(mon_block);
    return 0;
}

/* ============================================================
 * Flush de todas as entradas sujas
 * ============================================================ */
void cache_block_flush_all(void)
{
    sthread_monitor_enter(mon_block);
    for (int i = 0; i < BLOCK_CACHE_SIZE; i++)
        block_cache_flush_entry(i);
    sthread_monitor_exit(mon_block);
}

/* ============================================================
 * Write-back adiado — chamado pela thread de background
 * ============================================================ */
void cache_writeback_check(void)
{
    time_t now = time(NULL);
    sthread_monitor_enter(mon_block);
    for (int i = 0; i < BLOCK_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].dirty) {
            if (now - block_cache[i].dirty_time >= WRITEBACK_DELAY) {
                printf("[cache] writeback automatico bloco %u\n",
                       block_cache[i].block_no);
                block_cache_flush_entry(i);
            }
        }
    }
    sthread_monitor_exit(mon_block);
}

/* ============================================================
 * Cache de inodes
 * ============================================================ */
void cache_inode_flush_all(void)
{
    sthread_monitor_enter(mon_inode);
    for (int i = 0; i < INODE_CACHE_SIZE; i++) {
        if (inode_cache[i].valid && inode_cache[i].dirty) {
            printf("[cache] flush inode %u\n", inode_cache[i].inode_no);
            inode_cache[i].dirty = 0;
        }
    }
    sthread_monitor_exit(mon_inode);
}

/* ============================================================
 * Cache de directorias
 * ============================================================ */
void cache_dir_invalidate(unsigned dir_inode)
{
    sthread_monitor_enter(mon_dir);
    for (int i = 0; i < DIR_CACHE_SIZE; i++) {
        if (dir_cache[i].valid && dir_cache[i].dir_inode == dir_inode) {
            dir_cache[i].valid = 0;
            printf("[cache] invalidada cache dir inode %u\n", dir_inode);
        }
    }
    sthread_monitor_exit(mon_dir);
}
