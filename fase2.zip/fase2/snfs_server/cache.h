/*
 * cache.h - Cache de blocos, inodes e directorias para o SNFS
 */

#ifndef _CACHE_H_
#define _CACHE_H_

#include <time.h>
#include <sthread.h>
#include "block.h"
#include "fs.h"

/* ============================================================
 * Parametros das caches (facilmente alteraveis)
 * ============================================================ */
#define BLOCK_CACHE_SIZE  10
#define INODE_CACHE_SIZE   4
#define DIR_CACHE_SIZE     4
#define WRITEBACK_DELAY   10   /* segundos */
#define BLOCK_SIZE_CACHE 512

/* ============================================================
 * Cache de Blocos
 * ============================================================ */
typedef struct {
    int      valid;        /* entrada valida? */
    unsigned block_no;     /* numero do bloco */
    char     data[BLOCK_SIZE_CACHE]; /* conteudo do bloco */
    int      dirty;        /* foi modificado? */
    time_t   dirty_time;   /* quando foi marcado dirty */
    time_t   last_access;  /* para politica LRU */
} block_cache_entry_t;

/* ============================================================
 * Cache de Inodes
 * ============================================================ */
typedef struct {
    int       valid;
    unsigned  inode_no;
    char      data[64];    /* tamanho do inode = 64 bytes */
    int       dirty;
    time_t    dirty_time;
    time_t    last_access;
} inode_cache_entry_t;

/* ============================================================
 * Cache de Directorias
 * ============================================================ */
#define MAX_DIR_ENTRIES 32
typedef struct {
    char name[14];
    unsigned short inodeid;
} dir_cache_dentry_t;

typedef struct {
    int      valid;
    unsigned dir_inode;    /* inode do directorio */
    dir_cache_dentry_t entries[MAX_DIR_ENTRIES];
    int      num_entries;
    int      dirty;
    time_t   dirty_time;
    time_t   last_access;
} dir_cache_entry_t;

/* ============================================================
 * API da cache
 * ============================================================ */

/* Inicializa as 3 caches */
void cache_init(blocks_t* bks);

/* Cache de blocos */
int  cache_block_read(unsigned block_no, char* buf);
int  cache_block_write(unsigned block_no, char* buf);
void cache_block_flush_all(void);

/* Cache de inodes - flush selectivo */
void cache_inode_flush_all(void);

/* Cache de directorias - invalidar quando directorio muda */
void cache_dir_invalidate(unsigned dir_inode);

/* Flush de entradas sujas com mais de WRITEBACK_DELAY segundos */
void cache_writeback_check(void);

#endif /* _CACHE_H_ */
