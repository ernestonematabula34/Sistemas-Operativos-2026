/*
 * test_myfs.c - Teste usando a snfs_lib (my_open, my_read, my_write, etc.)
 */
#include <stdio.h>
#include <string.h>
#include "include/myfs.h"

int main() {
    printf("=== TESTE SNFS_LIB (multi-servidor) ===\n");

    if (my_init_lib() < 0) {
        printf("[ERRO] my_init_lib falhou\n");
        return 1;
    }
    printf("[OK] biblioteca inicializada\n");

    /* criar e escrever ficheiro */
    int fd = my_open("/teste2.txt", 1);
    if (fd < 0) { printf("[ERRO] my_open falhou\n"); return 1; }
    printf("[OK] ficheiro aberto/criado fd=%d\n", fd);

    char* msg = "Erros Coders - multi-servidor funciona!";
    int n = my_write(fd, msg, strlen(msg));
    printf("[OK] escritos %d bytes\n", n);
    my_close(fd);

    /* ler de volta */
    fd = my_open("/teste2.txt", 0);
    char buf[256] = {0};
    n = my_read(fd, buf, sizeof(buf)-1);
    printf("[OK] lidos %d bytes: '%s'\n", n, buf);
    my_close(fd);

    /* listar directorio */
    char* filenames = NULL;
    int numFiles = 0;
    my_listdir("/", &filenames, &numFiles);
    printf("[OK] %d ficheiros no /:\n", numFiles);
    char* p = filenames;
    for (int i = 0; i < numFiles; i++) {
        printf("     %s\n", p);
        p += strlen(p) + 1;
    }
    free(filenames);

    printf("=== TESTES CONCLUIDOS ===\n");
    return 0;
}
